# OSCAL Snapshot — IM8 Reform Control Catalog

- Source repository: https://github.com/GovTechSG/tech-standards
- License: MIT (© Government Technology Agency of Singapore, GovTech)
- Catalog title: Instruction Manual 8 Reform
- Catalog version: 2025.05.13
- Catalog last-modified: 2025-05-13T18:00:00+08:00
- OSCAL version: 1.1.2
- Fetched at (UTC): 2026-08-16T15:50:57Z
- Families: 15
- Controls: 137
- Files generated: 15 family files + INDEX.md + this snapshot

## Attribution (MIT License)

The control text in these reference files is derived from the OSCAL
catalog and profiles published by GovTech Singapore under the MIT
License. The following copyright and permission notice is reproduced
as required by that license:

```
MIT License

Copyright (c) 2024 Government Technology Agency of Singapore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
